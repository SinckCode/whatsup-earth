import React, { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';

export default function SplitView({ items = [] }) {
  const mapRef = useRef(null);
  const mapObj = useRef(null);

  useEffect(() => {
    if (!mapRef.current) return;
    mapObj.current = new maplibregl.Map({
      container: mapRef.current,
      style: 'https://demotiles.maplibre.org/style.json',
      center: [-98.35, 19.43], // MX approx
      zoom: 2
    });
    return () => mapObj.current && mapObj.current.remove();
  }, []);

  useEffect(() => {
    if (!mapObj.current) return;
    // limpia marcadores
    document.querySelectorAll('.ml-marker').forEach(n => n.remove());
    // coloca marcadores simples
    items.forEach(ev => {
      (ev.geometry || []).forEach(g => {
        const [lon, lat] = g.coordinates || [];
        if (typeof lon !== 'number' || typeof lat !== 'number') return;
        const el = document.createElement('div');
        el.className = 'ml-marker';
        el.style.cssText = 'width:10px;height:10px;border-radius:50%;background:#43c5f5;';
        new maplibregl.Marker(el).setLngLat([lon, lat]).addTo(mapObj.current);
      });
    });
  }, [items]);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', height: '100vh' }}>
      <div style={{ overflowY: 'auto', padding: 16, borderRight: '1px solid #13202a' }}>
        <h3 style={{ marginTop: 0 }}>Eventos ({items.length})</h3>
        {items.map(ev => (
          <div key={ev.id} style={{ marginBottom: 12, padding: 12, borderRadius: 12, background: '#0e141b' }}>
            <div style={{ fontWeight: 700 }}>{ev.title}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>
              {ev.categories?.map(c => c.title).join(', ')}
            </div>
          </div>
        ))}
      </div>
      <div ref={mapRef} />
    </div>
  );
}
