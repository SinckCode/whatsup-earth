/**
 * Adapter por AÑO: agrupa por mes (o por etiqueta que mandes) y suma eventos.
 * Espera items tipo: { label: string|number, count: number }
 */
export function adaptYearSeries(items, labelKey = "label", countKey = "count") {
  if (!Array.isArray(items)) return [];
  return items.map(it => ({
    name: String(it[labelKey]),
    value: Number(it[countKey] ?? 0),
  }));
}

/**
 * Adapter por PAÍS: agrupa por país/region.
 * Espera items tipo: { country: string, total: number }
 */
export function adaptCountrySeries(items, countryKey = "country", totalKey = "total") {
  if (!Array.isArray(items)) return [];
  return items.map(it => ({
    name: String(it[countryKey]),
    value: Number(it[totalKey] ?? 0),
  }));
}
