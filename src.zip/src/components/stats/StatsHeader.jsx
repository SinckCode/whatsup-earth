import { Globe2, Plus, Info, BarChart3 } from "lucide-react";
import "../../styles/components/stats/_statsHeader.scss";

export default function StatsHeader({
  title = "WILDFIRES",
  subtitle = "",
  onInfo,
  onAdd,
  onChart,
}) {
  return (
    <header className="stats-header">
      <div className="title-wrap">
        <Globe2 className="brand-icon" />
        <h2 className="title">{String(title).toUpperCase()}</h2>
        {subtitle ? <span className="subtitle">{subtitle}</span> : null}
      </div>

      <div className="actions">
        <button aria-label="Add" className="icon-btn" onClick={onAdd}>
          <Plus size={16} />
        </button>
        <button aria-label="Chart" className="icon-btn" onClick={onChart}>
          <BarChart3 size={16} />
        </button>
        <button aria-label="Info" className="icon-btn" onClick={onInfo}>
          <Info size={16} />
        </button>
      </div>
    </header>
  );
}
