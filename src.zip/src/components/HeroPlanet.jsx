import React from "react";

export default function HeroPlanet() {
  return (
    <div className="wu-hero-planet">
      <img src="./assets/earth-hero.jpg" alt="Earth from space" loading="eager" />
    </div>
  );
}
