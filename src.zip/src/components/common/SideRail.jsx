import React, { useEffect, useRef, useState } from "react";
import "../../styles/components/common/SideRail.scss";

const DISASTERS = ["WILDFIRES", "EARTHQUAKES", "DUST HAZE"];

export default function SideRail({
  onDisasterSelect = (k) => console.log("rail disaster:", k),
  onAction = (k) => console.log("rail action:", k),
  titleTop = "WHAT’S UP",
  titleBottom = "EARTH",
  showWordmark = true,
  className = "",
}) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const onDown = (e) => {
      if (!open) return;
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <aside className={`siderail ${className}`} role="complementary" aria-label="Left rail">
        {/* Botón del rail */}


        {/* Wordmark (puedes ocultarlo con showWordmark={false}) */}
        {showWordmark && (
          <h1 className="wordmark">
            <span className="wm-line wm-1">{titleTop}</span>
            <span className="wm-line wm-2">{titleBottom}</span>
          </h1>
        )}

        <button
          className="hamburger rail"
          aria-label="Menu"
          aria-haspopup="menu"
          aria-expanded={open}
          title="Menu"
          onClick={() => setOpen((v) => !v)}
        >
          <span />
        </button>
      </aside>

      {/* Overlay para cerrar con click-fuera */}
      <div className={`rail-scrim ${open ? "show" : ""}`} onClick={() => setOpen(false)} />

      {/* Menú lateral propio */}
      <nav
        ref={menuRef}
        className={`rail-menu ${open ? "open" : ""}`}
        role="menu"
        aria-label="Left rail menu"
      >
        <div className="rail-group">
          <button className="rail-item" role="menuitem" onClick={() => onAction("overview")}>
            Overview
          </button>
          <button className="rail-item" role="menuitem" onClick={() => onAction("live-globe")}>
            Live Globe
          </button>
          <button className="rail-item" role="menuitem" onClick={() => onAction("timeline")}>
            Timeline
          </button>
        </div>

        <div className="rail-sep" />

        <div className="rail-group">
          <div className="rail-label">Disasters</div>
          {DISASTERS.map((d) => (
            <button
              key={d}
              className="rail-item"
              role="menuitem"
              onClick={() => { onDisasterSelect(d); setOpen(false); }}
            >
              {d}
            </button>
          ))}
        </div>

        <div className="rail-sep" />

        <div className="rail-group">
          <button className="rail-item" role="menuitem" onClick={() => onAction("bookmarks")}>
            Bookmarks
          </button>
          <button className="rail-item" role="menuitem" onClick={() => onAction("settings")}>
            Settings
          </button>
          <button className="rail-item" role="menuitem" onClick={() => onAction("about")}>
            About
          </button>
        </div>
      </nav>
    </>
  );
}
