import React, { useEffect, useRef, useState, forwardRef } from "react";
import logoUrl from "../../../public/vite.svg"; // tip: en Vite también puedes usar "/vite.svg"
import "../../styles/components/common/TopBar.scss";

const DISASTER_ITEMS = ["WILDFIRES", "EARTHQUAKES", "DUST HAZE"];

/* Panel reutilizable para Add/Analytics */
const DisasterPanel = forwardRef(function DisasterPanel({ onSelect, className }, ref) {
  return (
    <div ref={ref} className={className} role="menu" aria-label="Disaster menu">
      {DISASTER_ITEMS.map((it) => (
        <button
          key={it}
          className="add-item"
          role="menuitem"
          onClick={() => onSelect?.(it)}
        >
          {it}
        </button>
      ))}
    </div>
  );
});

/* Popover de búsqueda */
const SearchPopover = forwardRef(function SearchPopover({ onSubmit }, ref) {
  const inputRef = useRef(null);
  useEffect(() => { inputRef.current?.focus(); }, []);
  return (
    <div ref={ref} className="search-pop" role="dialog" aria-label="Search">
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          const q = inputRef.current?.value?.trim() || "";
          onSubmit?.(q);
        }}
      >
        <input
          ref={inputRef}
          type="search"
          className="search-input"
          placeholder="Search events, places…"
          aria-label="Search query"
        />
      </form>
    </div>
  );
});

export default function TopBar({
  title = "GEO NATURE",
  onMenu = () => {},
  onAnalytics = () => {},
  onSearch = () => {},
  onAddSelect = (k) => console.log("add:", k),
  onAnalyticsSelect = (k) => console.log("analytics:", k),
}) {
  const [openAdd, setOpenAdd] = useState(false);
  const [openStats, setOpenStats] = useState(false);
  const [openSearch, setOpenSearch] = useState(false);

  const addBtnRef = useRef(null);
  const statsBtnRef = useRef(null);
  const searchBtnRef = useRef(null);

  const addPanelRef = useRef(null);
  const statsPanelRef = useRef(null);
  const searchPanelRef = useRef(null);

  const openOnly = (which) => {
    setOpenAdd(which === "add");
    setOpenStats(which === "stats");
    setOpenSearch(which === "search");
  };

  // Cerrar al hacer clic fuera o con Escape
  useEffect(() => {
    const onDown = (e) => {
      const t = e.target;
      const nodes = [
        addBtnRef.current, addPanelRef.current,
        statsBtnRef.current, statsPanelRef.current,
        searchBtnRef.current, searchPanelRef.current,
      ].filter(Boolean);
      if (nodes.every((n) => !n.contains(t))) openOnly(null);
    };
    const onKey = (e) => e.key === "Escape" && openOnly(null);
    document.addEventListener("pointerdown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  return (
    <header className="topbar" role="banner">
      <div className="brand">
        <img src={logoUrl} className="brand-logo" alt="Logo" />
        <span className="brand-title">{title}</span>

      </div>

      <div className="actions">
        {/* ＋ */}
        <button
          ref={addBtnRef}
          className="pill"
          aria-haspopup="menu"
          aria-expanded={openAdd}
          aria-label="Add"
          title="Add"
          onClick={() => openOnly(openAdd ? null : "add")}
        >
          +
        </button>

        {/* Analítica */}
        <button
          ref={statsBtnRef}
          className="pill"
          aria-haspopup="menu"
          aria-expanded={openStats}
          aria-label="Analytics"
          title="Analytics"
          onClick={() => {
            onAnalytics();
            openOnly(openStats ? null : "stats");
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
            <path d="M4 13v7M10 4v16M16 9v11M22 2v20"
              stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>

        {/* Búsqueda */}
        <button
          ref={searchBtnRef}
          className="pill"
          aria-haspopup="dialog"
          aria-expanded={openSearch}
          aria-label="Search"
          title="Search"
          onClick={() => openOnly(openSearch ? null : "search")}
        >
          🔍
        </button>

        {/* Panels */}
        {openAdd && (
          <DisasterPanel
            ref={addPanelRef}
            className="add-panel"
            onSelect={(k) => { onAddSelect(k); openOnly(null); }}
          />
        )}

        {openStats && (
          <DisasterPanel
            ref={statsPanelRef}
            className="stats-panel"
            onSelect={(k) => { onAnalyticsSelect(k); openOnly(null); }}
          />
        )}

        {openSearch && (
          <SearchPopover
            ref={searchPanelRef}
            onSubmit={(q) => { onSearch(q); openOnly(null); }}
          />
        )}
      </div>
    </header>
  );
}
