import { useQuery } from "@tanstack/react-query";
import { adaptCountrySeries } from "../components/stats/dataAdapters";
// Ajusta este import a tu fetch real:
import { fetchWildfiresByCountry } from "../eonet/queries"; // <- tu función ya existente

/**
 * @param {{ year?: number, categoryId?: string }}
 * Retorna data adaptada para la gráfica: [{ name, value }]
 */
export function useWildfiresByCountry({ year, categoryId }) {
  const qkey = ["wildfires-country", categoryId ?? "all", year ?? "all"];

  const query = useQuery({
    queryKey: qkey,
    queryFn: async ({ signal }) => {
      const raw = await fetchWildfiresByCountry({ year, categoryId, signal });
      // raw debe contener algo tipo [{ country, total }]
      return adaptCountrySeries(raw.items ?? raw, raw.countryKey ?? "country", raw.totalKey ?? "total");
    },
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
  });

  return { ...query, data: query.data ?? [] };
}
