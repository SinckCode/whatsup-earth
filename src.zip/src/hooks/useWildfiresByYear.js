import { useQuery } from "@tanstack/react-query";
import { adaptYearSeries } from "../components/stats/dataAdapters";
// Ajusta este import a tu fetch real:
import { fetchWildfiresByYear } from "../eonet/queries"; // <- tu función ya existente

/**
 * @param {{ year: number, categoryId?: string, signal?: AbortSignal }}
 * Retorna data adaptada para la gráfica: [{ name, value }]
 */
export function useWildfiresByYear({ year, categoryId }) {
  const qkey = ["wildfires-year", categoryId ?? "all", year];

  const query = useQuery({
    queryKey: qkey,
    queryFn: async ({ signal }) => {
      const raw = await fetchWildfiresByYear({ year, categoryId, signal });
      // raw debe contener algo tipo [{ label, count }]
      return adaptYearSeries(raw.items ?? raw, raw.labelKey ?? "label", raw.countKey ?? "count");
    },
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
  });

  return { ...query, data: query.data ?? [] };
}
