const BASE = "https://eonet.gsfc.nasa.gov/api/v3";

export async function getEventsByCategory({ categoryId, year, limit = 100 }) {
  const params = new URLSearchParams();
  if (year) params.set("year", String(year));
  if (limit) params.set("limit", String(limit));
  // categoría via /events?category=…
  if (categoryId) params.set("category", String(categoryId));

  const res = await fetch(`${BASE}/events?${params.toString()}`);
  if (!res.ok) throw new Error("EONET error");
  const data = await res.json();
  // Adapter mínimo: normaliza a {id, title, date, coordinates, categories}
  return (data?.events ?? []).map((e) => ({
    id: e.id,
    title: e.title,
    date: e.geometry?.[0]?.date ?? e.closed ?? null,
    coordinates: e.geometry?.[0]?.coordinates ?? null,
    categories: e.categories?.map((c) => c.id) ?? [],
    raw: e,
  }));
}

/**
 * País por coordenadas (placeholder):
 * - Opción A (recomendada): lookup rápido en un GeoJSON topo simplificado (world-atlas)
 * - Opción B: servicio geocoding (Nominatim) -> no usar en producción sin backend
 *
 * Por ahora dejamos la firma y retornamos null para que la UI muestre "sin país".
 */
export async function countryFromCoords([lon, lat]) {
  void lon; void lat;
  return null;
}
