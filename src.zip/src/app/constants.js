export const DISASTERS = [
  {
    key: "wildfires",
    label: "WILDFIRES",
    bg: "/assets/hero/wildfires.jpg",
    eonetCategoryId: 8, // referencial; ajusta al id real que uses
  },
  {
    key: "earthquakes",
    label: "EARTHQUAKES",
    bg: "/assets/hero/earthquakes.jpg",
    eonetCategoryId: 16,
  },
  {
    key: "dust-haze",
    label: "DUST HAZE",
    bg: "/assets/hero/dusthaze.jpg",
    eonetCategoryId: 7,
  },
];
