import { eonet } from "./client"; // <-- tu axios.create({ baseURL: 'https://eonet.gsfc.nasa.gov/api/v3' })

/* =========================
   HELPERS
   ========================= */
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

function safeGet(arr, key, def = []) {
  try { return Array.isArray(arr) ? arr : def; } catch { return def; }
}
function dateToMonthIdx(iso) {
  const m = new Date(iso);
  const idx = m.getUTCMonth?.() ?? m.getMonth?.() ?? 0;
  return Math.max(0, Math.min(11, idx));
}

/**
 * Heurística simple para país: intenta matchear por título.
 * Ajusta/expande esta lista según tus necesidades reales.
 */
const COUNTRY_ALIASES = [
  "México","Mexico","United States","USA","EUA","Canada","Canadá",
  "Chile","Argentina","Brazil","Brasil","Zambia","Angola","Russia","Rusia",
  "India","Japan","Japón","Spain","España","France","Francia","Africa","África"
];
function guessCountryFromTitle(title = "") {
  const t = String(title).toLowerCase();
  for (const name of COUNTRY_ALIASES) {
    if (t.includes(name.toLowerCase())) return name.replace("United States","EUA");
  }
  return "Other";
}

/* =========================
   FETCHERS PARA WILDFIRES
   ========================= */

/**
 * Eventos por AÑO → serie mensual.
 * Devuelve:
 * {
 *   items: [{ label: "Jan", count: 12 }, ...],
 *   labelKey: "label",
 *   countKey: "count"
 * }
 */
export async function fetchWildfiresByYear({ year, categoryId = "wildfires", signal } = {}) {
  // EONET /events?category=wildfires&status=open&start=YYYY-01-01&end=YYYY-12-31&limit=500
  const start = `${year}-01-01`;
  const end = `${year}-12-31`;

  const { data } = await eonet.get("/events", {
    params: { category: categoryId, status: "open", start, end, limit: 500 },
    signal
  });

  const events = data?.events ?? data ?? [];
  const buckets = new Array(12).fill(0);

  for (const ev of events) {
    // usa la primera geometría (la mayoría de los eventos la tienen)
    const geo = safeGet(ev?.geometry)[0];
    const when = geo?.date || ev?.geometry?.[0]?.date || ev?.closed || ev?.opened;
    if (!when) continue;
    const idx = dateToMonthIdx(when);
    buckets[idx] += 1;
  }

  return {
    items: buckets.map((count, i) => ({ label: MONTHS[i], count })),
    labelKey: "label",
    countKey: "count"
  };
}

/**
 * Eventos por PAÍS (heurística por título) en el año dado.
 * Devuelve:
 * {
 *   items: [{ country: "México", total: 123 }, ...],
 *   countryKey: "country",
 *   totalKey: "total"
 * }
 */
export async function fetchWildfiresByCountry({ year, categoryId = "wildfires", signal } = {}) {
  const start = `${year}-01-01`;
  const end = `${year}-12-31`;

  const { data } = await eonet.get("/events", {
    params: { category: categoryId, status: "open", start, end, limit: 500 },
    signal
  });

  const events = data?.events ?? data ?? [];
  const map = new Map();

  for (const ev of events) {
    const title = ev?.title ?? "";
    const country = guessCountryFromTitle(title); // "México", "EUA", "Other", etc.
    map.set(country, (map.get(country) ?? 0) + 1);
  }

  const items = Array.from(map.entries())
    .map(([country, total]) => ({ country, total }))
    .sort((a, b) => b.total - a.total);

  return {
    items,
    countryKey: "country",
    totalKey: "total"
  };
}

/* =========================
   HOOKS EXISTENTES (si ya tienes otros, mantenlos)
   ========================= */

// ejemplo de tus hooks previos, mantenlos si los usas en otras partes
// export const useCategories = () => ...
// export const useEventsByCategory = (...) => ...
