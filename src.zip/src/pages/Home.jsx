import React, { useEffect, useRef } from "react";
import TopBar from "../components/common/TopBar";
import SideRail from "../components/common/SideRail";
import GlobeHero from "../components/GlobeHero.jsx";
import DisasterCarousel from "../components/home/DisasterCarousel.jsx";

export default function Home() {
  const heroRef = useRef(null);
  const slidesSectionRef = useRef(null);

  // 1) Desde el HERO: si se scrollea hacia abajo, "salta" al carrusel
  useEffect(() => {
    const heroEl = heroRef.current;
    if (!heroEl) return;

    const onWheelFromHero = (e) => {
      // sólo interceptamos scroll hacia abajo
      if (e.deltaY > 8) {
        e.preventDefault();
        slidesSectionRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    };

    heroEl.addEventListener("wheel", onWheelFromHero, { passive: false });
    return () => heroEl.removeEventListener("wheel", onWheelFromHero);
  }, []);

  // 2) En el carrusel: mapear rueda vertical → scroll horizontal + snap
  useEffect(() => {
    // El track puede ser .slides dentro del section, o el propio section
    const section = slidesSectionRef.current;
    if (!section) return;

    const track =
      section.querySelector(".slides") /* si tu DisasterCarousel la usa */ ||
      section;

    const onWheelToHorizontal = (e) => {
      // si el eje dominante es vertical, lo convertimos a horizontal
      if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
        e.preventDefault();
        track.scrollBy({ left: e.deltaY, behavior: "smooth" });
      }
    };

    track.addEventListener("wheel", onWheelToHorizontal, { passive: false });
    return () => track.removeEventListener("wheel", onWheelToHorizontal);
  }, []);

  // 3) Activar transición entre slides (fade/translate del overlay cuando es activa)
  useEffect(() => {
    const section = slidesSectionRef.current;
    if (!section) return;

    const root =
      section.querySelector(".slides") /* preferible */ || section;

    // Observa visibilidad de cada .slide dentro del carrusel
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting && en.intersectionRatio >= 0.55) {
            en.target.setAttribute("data-active", "true");
          } else {
            en.target.removeAttribute("data-active");
          }
        });
      },
      { root, threshold: [0.55] }
    );

    root.querySelectorAll(".slide").forEach((slide) => io.observe(slide));
    return () => io.disconnect();
  }, []);

  return (
    <main className="home">
      <TopBar />
      <SideRail />

      {/* Sección 1: H E R O con globo */}
      <section ref={heroRef} className="hero-section">
        <div className="hero-planet">
          <GlobeHero />
        </div>
      </section>

      {/* Sección 2: C A R R U S E L de desastres */}
      <section ref={slidesSectionRef} className="slides-section">
        <DisasterCarousel />
      </section>
    </main>
  );
}
