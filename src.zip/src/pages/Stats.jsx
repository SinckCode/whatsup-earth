import { useMemo, useState, useEffect } from "react";
import StatsHeader from "../components/stats/StatsHeader";
import ChartShell from "../components/stats/ChartShell";
import StatsToggle from "../components/stats/StatsToggle";
import YearPicker from "../components/stats/YearPicker";
import CountryPicker from "../components/stats/CountryPicker";
import EventList from "../components/stats/EventList";
import StatsBarChart from "../components/stats/StatsBarChart";

// Hooks de datos (ajusta las rutas si difieren en tu proyecto)
import { useWildfiresByYear } from "../hooks/useWildfiresByYear";
import { useWildfiresByCountry } from "../hooks/useWildfiresByCountry";

export default function StatsPage() {
  const years = Array.from({ length: 7 }, (_, i) => 2025 - i);
  const countriesFallback = ["Africa","México","EUA","Zambia","Angola","Chile","Rusia","India","Japón","Canadá"];

  const [mode, setMode] = useState("year");            // "year" | "country"
  const [year, setYear] = useState(years[0]);
  const [country, setCountry] = useState(countriesFallback[0]);
  const [activeKey, setActiveKey] = useState(null);    // sincroniza ranking <-> chart

  // Si usas categorías por hazard, cámbialo según tu router/estado
  const categoryId = "wildfires";

  // Datos por año (serie mensual, por ejemplo) y por país (top países)
  const { data: dataYear, isLoading: loadingYear } = useWildfiresByYear({ year, categoryId });
  const { data: dataCountry, isLoading: loadingCountry } = useWildfiresByCountry({ year, categoryId });

  // Países para el picker: intenta usar los países de la data si existen
  const countriesFromData = useMemo(
    () => uniqueNames(dataCountry),
    [dataCountry]
  );
  const countries = countriesFromData.length ? countriesFromData : countriesFallback;

  // Items del ranking (EventList) a partir de dataCountry
  const eventItems = useMemo(
    () => toEventItems(dataCountry, 20), // top 20 (ajusta si quieres)
    [dataCountry]
  );

  // Total WORLD (suma de valores)
  const worldTotal = useMemo(
    () => sumValues(dataCountry),
    [dataCountry]
  );

  // Cuando cambie el modo, resetea selección activa
  useEffect(() => {
    setActiveKey(null);
  }, [mode, year]);

  // Al cambiar el país por picker, marca activo en ranking si coincide
  useEffect(() => {
    if (!country) return;
    const match = eventItems.find(it => it.label === country || it.key === country);
    setActiveKey(match ? (match.key ?? match.label) : null);
  }, [country, eventItems]);

  const isYearMode = mode === "year";
  const chartData = isYearMode ? dataYear : dataCountry;
  const chartLoading = isYearMode ? loadingYear : loadingCountry;

  return (
    <div className="stats-page">
      <div className="container" style={{ maxWidth: "1120px", margin: "0 auto" }}>
        <StatsHeader
          title="Wildfires"
          subtitle={isYearMode ? `Year ${year}` : country}
        />

        <div className="grid-main">
          <div className="space-y-4">
<ChartShell height="clamp(280px, 34vw, 440px)">
  <StatsBarChart
    data={chartData}
    xKey="name"
    yKey="value"
    unit="events"
    loading={chartLoading}
    onBarClick={(row) => { if (!row || isYearMode) return; setActiveKey(row.name); setCountry(row.name); }}
  />
</ChartShell>

            <div className="stats-toolbar">
              <StatsToggle mode={mode} onChange={setMode} />
              <div className="filters-pill">
                <span className="label">Filters</span>
              </div>
            </div>
          </div>

          <EventList
            title="WORLD"
            total={worldTotal}
            items={eventItems}
            activeKey={activeKey}
            onSelect={(it) => {
              setActiveKey(it.key ?? it.label);
              setCountry(it.label);          // sincroniza con CountryPicker
              setMode("country");            // si estabas en YEAR, muévete a COUNTRY
            }}
          />
        </div>

        {isYearMode ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <YearPicker years={years} selectedYear={year} onSelect={setYear} />
            <div className="hidden md:block" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <CountryPicker countries={countries} selected={country} onSelect={(c) => {
              setCountry(c);
              // Marca activo en ranking si existe ese país
              const match = eventItems.find(it => it.label === c || it.key === c);
              setActiveKey(match ? (match.key ?? match.label) : null);
            }} />
            <div className="hidden md:block" />
          </div>
        )}
      </div>
    </div>
  );
}

/* =========================
   Helpers (puedes moverlos a utils)
   ========================= */

function toEventItems(countrySeries = [], topN = 20) {
  // Espera countrySeries: [{ name, value }]
  if (!Array.isArray(countrySeries)) return [];
  return countrySeries
    .map((row) => ({
      key: row.name,
      label: String(row.name),
      value: Number(row.value ?? 0),
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, topN);
}

function sumValues(series = []) {
  if (!Array.isArray(series)) return 0;
  return series.reduce((acc, r) => acc + Number(r?.value ?? 0), 0);
}

function uniqueNames(series = []) {
  if (!Array.isArray(series)) return [];
  const set = new Set(series.map((r) => String(r?.name ?? "").trim()).filter(Boolean));
  return Array.from(set);
}
